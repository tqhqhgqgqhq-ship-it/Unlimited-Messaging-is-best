const fs = require('fs');
const https = require('https');
const path = require('path');
const AdmZip = require('adm-zip');

const ZIP_URL = "https://raw.githubusercontent.com/tqhqhgqgqhq-ship-it/Messaging-app-UI/main/integrate-existing-messaging-app%20(4).zip";
const OUT_ZIP = path.join(__dirname, "app.zip");
const TARGET_DIR = path.resolve(__dirname, "..");

console.log("Starting download of ZIP...");

https.get(ZIP_URL, (res) => {
  if (res.statusCode !== 200) {
    console.error("Failed to download zip, status: " + res.statusCode);
    process.exit(1);
  }
  
  const file = fs.createWriteStream(OUT_ZIP);
  res.pipe(file);
  
  file.on('finish', () => {
    file.close();
    console.log("Download complete! Extracting...");
    try {
      const zip = new AdmZip(OUT_ZIP);
      zip.extractAllTo(TARGET_DIR, true);
      console.log("Extraction complete!");
    } catch (e) {
      console.error("Extraction failed: ", e);
      
      // Let's try the other zip file if this one fails
      console.log("Trying the other zip file...");
      const ZIP_URL_2 = "https://raw.githubusercontent.com/tqhqhgqgqhq-ship-it/Messaging-app-UI/main/messaging-app-integration-project%20(3).zip";
      
      https.get(ZIP_URL_2, (res2) => {
        const file2 = fs.createWriteStream(OUT_ZIP);
        res2.pipe(file2);
        file2.on('finish', () => {
          file2.close();
          const zip2 = new AdmZip(OUT_ZIP);
          zip2.extractAllTo(TARGET_DIR, true);
          console.log("Extraction 2 complete!");
        });
      });
    }
  });
}).on('error', (err) => {
  console.error("Error downloading: ", err.message);
});
