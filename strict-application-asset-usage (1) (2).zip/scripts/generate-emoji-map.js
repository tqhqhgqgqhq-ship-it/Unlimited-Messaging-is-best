/**
 * Auto-generates emoji animation mapping from GIF files.
 * Run this after placing your 1000+ emoji GIFs in public/emoji/
 * 
 * Usage: node scripts/generate-emoji-map.js
 */

const fs = require('fs');
const path = require('path');

const EMOJI_DIR = path.join(__dirname, '..', 'public', 'emoji');
const OUTPUT_FILE = path.join(__dirname, '..', 'src', 'lib', 'emoji-animations-generated.ts');

// Common emoji name mappings
const EMOJI_NAME_MAP = {
  'grinning': '😀',
  'smiley': '😃',
  'smile': '😄',
  'grin': '😁',
  'laughing': '😆',
  'sweat_smile': '😅',
  'rofl': '🤣',
  'joy': '😂',
  'slight_smile': '🙂',
  'upside_down': '🙃',
  'wink': '😉',
  'blush': '😊',
  'innocent': '😇',
  'smiling_face_with_hearts': '🥰',
  'heart_eyes': '😍',
  'star_struck': '🤩',
  'kissing_heart': '😘',
  'kissing': '😗',
  'kissing_closed_eyes': '😚',
  'kissing_smiling_eyes': '😙',
  'yum': '😋',
  'stuck_out_tongue': '😛',
  'stuck_out_tongue_winking_eye': '😜',
  'zany_face': '🤪',
  'stuck_out_tongue_closed_eyes': '😝',
  'money_mouth_face': '🤑',
  'hugs': '🤗',
  'hand_over_mouth': '🤭',
  'shushing_face': '🤫',
  'thinking': '🤔',
  'zipper_mouth': '🤐',
  'raised_eyebrow': '🤨',
  'neutral_face': '😐',
  'expressionless': '😑',
  'no_mouth': '😶',
  'smirk': '😏',
  'unamused': '😒',
  'roll_eyes': '🙄',
  'grimacing': '😬',
  'lying_face': '🤥',
  'relieved': '😌',
  'pensive': '😔',
  'sleepy': '😪',
  'drooling_face': '🤤',
  'sleeping': '😴',
  'mask': '😷',
  'face_with_thermometer': '🤒',
  'face_with_head_bandage': '🤕',
  'nauseated_face': '🤢',
  'vomiting_face': '🤮',
  'sneezing_face': '🤧',
  'hot_face': '🥵',
  'cold_face': '🥶',
  'woozy_face': '🥴',
  'dizzy_face': '😵',
  'exploding_head': '🤯',
  'cowboy_hat_face': '🤠',
  'partying_face': '🥳',
  'disguised_face': '🥸',
  'sunglasses': '😎',
  'nerd_face': '🤓',
  'monocle_face': '🧐',
  'confused': '😕',
  'worried': '😟',
  'slight_frown': '🙁',
  'frown': '☹️',
  'open_mouth': '😮',
  'hushed': '😯',
  'astonished': '😲',
  'flushed': '😳',
  'pleading_face': '🥺',
  'frowning': '😦',
  'anguished': '😧',
  'fearful': '😨',
  'cold_sweat': '😰',
  'disappointed_relieved': '😥',
  'cry': '😢',
  'sob': '😭',
  'scream': '😱',
  'confounded': '😖',
  'persevere': '😣',
  'disappointed': '😞',
  'sweat': '😓',
  'weary': '😩',
  'tired_face': '😫',
  'yawning_face': '🥱',
  'triumph': '😤',
  'rage': '😡',
  'angry': '😠',
  'cursing_face': '🤬',
  'smiling_imp': '😈',
  'imp': '👿',
  'skull': '💀',
  'hankey': '💩',
  'clown_face': '🤡',
  'japanese_ogre': '👹',
  'japanese_goblin': '👺',
  'ghost': '👻',
  'alien': '👽',
  'space_invader': '👾',
  'robot': '🤖',
  'smiley_cat': '😺',
  'smile_cat': '😸',
  'joy_cat': '😹',
  'heart_eyes_cat': '😻',
  'smirk_cat': '😼',
  'kissing_cat': '😽',
  'scream_cat': '🙀',
  'crying_cat_face': '😿',
  'pouting_cat': '😾',
  'see_no_evil': '🙈',
  'hear_no_evil': '🙉',
  'speak_no_evil': '🙊',
  'kiss': '💋',
  'love_letter': '💌',
  'cupid': '💘',
  'gift_heart': '💝',
  'sparkling_heart': '💖',
  'heartpulse': '💗',
  'heartbeat': '💓',
  'revolving_hearts': '💞',
  'two_hearts': '💕',
  'heart_decoration': '💟',
  'broken_heart': '💔',
  'heart': '❤️',
  'orange_heart': '🧡',
  'yellow_heart': '💛',
  'green_heart': '💚',
  'blue_heart': '💙',
  'purple_heart': '💜',
  'brown_heart': '🤎',
  'black_heart': '🖤',
  'white_heart': '🤍',
  '100': '💯',
  'anger': '💢',
  'boom': '💥',
  'dizzy': '💫',
  'sweat_drops': '💦',
  'dash': '💨',
  'speech_balloon': '💬',
  'thought_balloon': '💭',
  'zzz': '💤',
};

function generateEmojiMap() {
  if (!fs.existsSync(EMOJI_DIR)) {
    console.log(`❌ Emoji directory not found: ${EMOJI_DIR}`);
    console.log('Please create public/emoji/ and add your GIF files there.');
    return;
  }

  const files = fs.readdirSync(EMOJI_DIR).filter(f => f.endsWith('.gif'));
  
  if (files.length === 0) {
    console.log('⚠️ No GIF files found in public/emoji/');
    return;
  }

  console.log(`📦 Found ${files.length} emoji GIF files`);

  const mappings = files.map(file => {
    const name = file.replace('.gif', '');
    const char = EMOJI_NAME_MAP[name] || '❓';
    return `  { char: '${char}', name: '${name}', animationUrl: '/emoji/${name}.gif', fallback: '${char}' }`;
  });

  const output = `/**
 * ════════════════════════════════════════════════════════════════
 *  AUTO-GENERATED EMOJI ANIMATION MAPPING
 *  Generated from public/emoji/ GIF files
 * ════════════════════════════════════════════════════════════════ */

export interface EmojiAnimation {
  char: string;
  name: string;
  animationUrl: string;
  fallback: string;
}

export const EMOJI_ANIMATIONS_GENERATED: EmojiAnimation[] = [
${mappings.join(',\n')}
];

export const EMOJI_MAP_GENERATED: Map<string, EmojiAnimation> = new Map(
  EMOJI_ANIMATIONS_GENERATED.map((e) => [e.char, e])
);
`;

  fs.writeFileSync(OUTPUT_FILE, output);
  console.log(`✅ Generated ${OUTPUT_FILE}`);
  console.log(`📊 Total emoji mapped: ${files.length}`);
  console.log('\n📝 Next steps:');
  console.log('1. Import EMOJI_ANIMATIONS_GENERATED in src/lib/emoji-animations.ts');
  console.log('2. Merge with existing EMOJI_ANIMATIONS array');
  console.log('3. Rebuild the app: npm run build');
}

generateEmojiMap();
