import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "../../context/AuthContext";
import ActionSheet from "../ActionSheet";
type ActionItem = { label: string; icon?: React.ReactNode; destructive?: boolean; onClick: () => void };
import {
  getGroupInfo,
  listGroupMembers,
  listGroupTags,
  createGroupTag,
  assignMemberTag,
  removeMemberTag,
  setGroupMemberRole,
  removeGroupMember,
  updateGroupProfile,
  type GroupInfo,
  type GroupMember,
  type GroupTag,
  type GroupRole,
} from "../../lib/turso";

const Ico = ({ d, s = 20, c = "currentColor", strokeWidth = "2" }: { d: string; s?: number; c?: string; strokeWidth?: string }) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" dangerouslySetInnerHTML={{ __html: d }} />
);

const I = {
  back: (p: any) => <Ico {...p} d='<path d="M19 12H5M12 19l-7-7 7-7"/>' />,
  camera: (p: any) => <Ico {...p} d='<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>' />,
  edit: (p: any) => <Ico {...p} d='<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>' />,
  userPlus: (p: any) => <Ico {...p} d='<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>' />,
  shield: (p: any) => <Ico {...p} d='<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' />,
  tag: (p: any) => <Ico {...p} d='<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>' />,
  trash: (p: any) => <Ico {...p} d='<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>' />,
  more: (p: any) => <Ico {...p} d='<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>' />,
  check: (p: any) => <Ico {...p} d='<polyline points="20 6 9 17 4 12"/>' />,
  users: (p: any) => <Ico {...p} d='<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>' />,
  x: (p: any) => <Ico {...p} d='<path d="M18 6L6 18M6 6l12 12"/>' />
};

export default function GroupDetailsSheet({
  chat,
  onClose,
}: {
  chat: any;
  onClose: () => void;
}) {
  const { user } = useAuth();
  const [info, setInfo] = useState<GroupInfo | null>(chat.groupInfo || null);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [tags, setTags] = useState<GroupTag[]>([]);
  const [loading, setLoading] = useState(true);

  // Edit states
  const [editName, setEditName] = useState(false);
  const [editDesc, setEditDesc] = useState(false);
  const [nameVal, setNameVal] = useState("");
  const [descVal, setDescVal] = useState("");
  const [uploading, setUploading] = useState(false);

  // Action states
  const [actionMember, setActionMember] = useState<GroupMember | null>(null);
  const [tagManageMember, setTagManageMember] = useState<GroupMember | null>(null);

  // Load group data
  const loadData = async () => {
    if (!user) return;
    try {
      const [gi, mems, tgs] = await Promise.all([
        getGroupInfo(chat.id, user.uid),
        listGroupMembers(chat.id),
        listGroupTags(chat.id),
      ]);
      if (gi) {
        setInfo(gi);
        setNameVal(gi.name);
        setDescVal(gi.description || "");
      }
      setMembers(mems);
      setTags(tgs);
      setLoading(false);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, [chat.id, user]);

  const isAdmin = info?.myRole === "admin" || info?.myRole === "owner";
  const isOwner = info?.myRole === "owner";

  // Actions
  const handleSaveInfo = async (type: "name" | "desc") => {
    if (!user || !info) return;
    try {
      const patch = type === "name" ? { name: nameVal } : { description: descVal };
      await updateGroupProfile(info.id, user.uid, user.name, patch);
      if (type === "name") setEditName(false);
      if (type === "desc") setEditDesc(false);
      await loadData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleIconPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!user || !info) return;
    const f = e.target.files?.[0];
    if (!f) return;
    setUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        await updateGroupProfile(info.id, user.uid, user.name, { iconUrl: reader.result as string });
        await loadData();
        setUploading(false);
      };
      reader.readAsDataURL(f);
    } catch {
      setUploading(false);
    }
  };

  const handleMemberAction = (member: GroupMember) => {
    if (!isAdmin) return; // Only admins can manage others
    if (member.userId === user?.uid) return; // Can't manage self through this menu
    setActionMember(member);
  };

  // Build ActionSheet items for the selected member
  const buildActionItems = (): ActionItem[] => {
    if (!actionMember || !user || !info) return [];
    const items: ActionItem[] = [];

    // Tag assignment
    items.push({
      label: "Manage Tags",
      icon: <I.tag s={18} />,
      onClick: () => {
        setActionMember(null);
        setTimeout(() => setTagManageMember(actionMember), 300);
      }
    });

    // Roles (Owner only)
    if (isOwner) {
      if (actionMember.role === "admin") {
        items.push({
          label: "Revoke Admin",
          icon: <I.shield s={18} />,
          onClick: async () => {
            setActionMember(null);
            await setGroupMemberRole(info.id, user.uid, user.name, actionMember.userId, actionMember.name, "member");
            loadData();
          }
        });
      } else if (actionMember.role === "member") {
        items.push({
          label: "Make Admin",
          icon: <I.shield s={18} />,
          onClick: async () => {
            setActionMember(null);
            await setGroupMemberRole(info.id, user.uid, user.name, actionMember.userId, actionMember.name, "admin");
            loadData();
          }
        });
      }
    }

    // Removal
    // Admins can remove members. Owners can remove anyone.
    if (isOwner || (isAdmin && actionMember.role === "member")) {
      items.push({
        label: "Remove from Group",
        icon: <I.trash s={18} />,
        destructive: true,
        onClick: async () => {
          setActionMember(null);
          await removeGroupMember(info.id, user.uid, user.name, actionMember.userId, actionMember.name);
          loadData();
        }
      });
    }

    return items;
  };

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "spring", stiffness: 300, damping: 32 }}
      className="fixed inset-0 z-50 flex flex-col bg-[#050403] sm:rounded-[44px] overflow-hidden"
    >
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 border-b border-[rgba(216,173,90,0.1)] bg-[rgba(11,9,7,0.95)] backdrop-blur-xl">
        <button onClick={onClose} className="p-2 -ml-2 rounded-xl hover:bg-white/[0.06] transition-colors text-[#F3EADB]">
          <I.back s={20} />
        </button>
        <div className="flex-1 min-w-0">
          <p className="text-[16px] font-bold text-[#F3EADB]">Group Info</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scroll-area pb-12">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#D8AD5A]/30 border-t-[#D8AD5A] rounded-full animate-spin" />
          </div>
        ) : info ? (
          <div className="p-4 space-y-6">
            {/* HERO SECTION */}
            <div className="flex flex-col items-center">
              <div className="relative mb-4">
                <div
                  className="w-[120px] h-[120px] rounded-[32px] overflow-hidden flex items-center justify-center shadow-[0_12px_30px_rgba(0,0,0,0.5)]"
                  style={{ background: info.iconUrl ? "transparent" : "linear-gradient(160deg,#2A2520,#14110D)", border: "1.5px solid rgba(216,173,90,0.22)" }}
                >
                  {info.iconUrl ? (
                    <img src={info.iconUrl} className="w-full h-full object-cover" alt="" />
                  ) : (
                    <I.users s={40} c="#6E6353" />
                  )}
                </div>
                {isAdmin && (
                  <label className="absolute -bottom-2 -right-2 w-[40px] h-[40px] rounded-full flex items-center justify-center cursor-pointer hover:scale-105 transition-transform"
                    style={{ background: "linear-gradient(170deg,#FFF1CC,#E3B25D 42%,#A87527 82%)", boxShadow: "0 4px 12px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,248,220,.6)" }}>
                    {uploading ? <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" /> : <I.camera s={18} c="#1A1206" />}
                    <input type="file" accept="image/*" hidden onChange={handleIconPick} />
                  </label>
                )}
              </div>

              {editName ? (
                <div className="flex items-center gap-2 w-full max-w-[280px]">
                  <input
                    value={nameVal}
                    onChange={(e) => setNameVal(e.target.value)}
                    autoFocus
                    className="flex-1 h-10 px-3 rounded-xl bg-[rgba(255,244,210,0.05)] border border-[rgba(216,173,90,0.4)] text-[#F3EADB] text-[18px] font-bold text-center outline-none"
                  />
                  <button onClick={() => handleSaveInfo("name")} className="p-2 rounded-xl bg-[#D8AD5A] text-black">
                    <I.check s={18} />
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h2 className="text-[22px] font-bold text-[#F3EADB] text-center">{info.name}</h2>
                  {isAdmin && (
                    <button onClick={() => setEditName(true)} className="text-[#8A7D67] hover:text-[#D8AD5A] transition-colors">
                      <I.edit s={16} />
                    </button>
                  )}
                </div>
              )}
              <p className="text-[13px] text-[#8A7D67] mt-1 font-medium">Group • {info.memberCount} members</p>
            </div>

            {/* DESCRIPTION */}
            <div className="rounded-3xl p-4 bg-[rgba(255,244,210,0.02)] border border-[rgba(255,244,210,0.06)]">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-[12px] font-bold text-[#D8AD5A] uppercase tracking-wider">Description</h3>
                {isAdmin && !editDesc && (
                  <button onClick={() => setEditDesc(true)} className="text-[#8A7D67] hover:text-[#D8AD5A]">
                    <I.edit s={14} />
                  </button>
                )}
              </div>
              {editDesc ? (
                <div>
                  <textarea
                    value={descVal}
                    onChange={(e) => setDescVal(e.target.value)}
                    autoFocus
                    rows={3}
                    placeholder="Add a group description..."
                    className="w-full bg-[rgba(255,244,210,0.04)] border border-[rgba(216,173,90,0.4)] rounded-xl p-3 text-[14px] text-[#F3EADB] outline-none resize-none"
                  />
                  <div className="flex justify-end mt-2 gap-2">
                    <button onClick={() => { setEditDesc(false); setDescVal(info.description); }} className="px-4 py-1.5 rounded-lg text-[13px] font-semibold text-[#8A7D67] hover:bg-white/[0.05]">Cancel</button>
                    <button onClick={() => handleSaveInfo("desc")} className="px-4 py-1.5 rounded-lg text-[13px] font-bold bg-[#D8AD5A] text-black">Save</button>
                  </div>
                </div>
              ) : (
                <p className="text-[14px] text-[#EBE7E1] leading-relaxed whitespace-pre-wrap break-words">
                  {info.description || <span className="text-[#6E6353] italic">No description provided.</span>}
                </p>
              )}
            </div>

            {/* QUICK ACTIONS */}
            <div className="flex gap-3">
              {isAdmin && (
                <button className="flex-1 flex flex-col items-center justify-center gap-2 p-4 rounded-3xl bg-[rgba(255,244,210,0.03)] border border-[rgba(255,244,210,0.06)] hover:bg-[rgba(255,244,210,0.06)] transition-colors text-[#D8AD5A]">
                  <I.userPlus s={22} />
                  <span className="text-[12px] font-bold">Add Member</span>
                </button>
              )}
              <button className="flex-1 flex flex-col items-center justify-center gap-2 p-4 rounded-3xl bg-[rgba(255,244,210,0.03)] border border-[rgba(255,244,210,0.06)] hover:bg-[rgba(255,244,210,0.06)] transition-colors text-[#F3EADB]">
                <I.tag s={22} />
                <span className="text-[12px] font-bold">Tags ({tags.length})</span>
              </button>
            </div>

            {/* MEMBERS LIST */}
            <div className="rounded-3xl bg-[rgba(255,244,210,0.02)] border border-[rgba(255,244,210,0.06)] overflow-hidden">
              <div className="px-5 py-4 border-b border-[rgba(255,244,210,0.06)] flex items-center justify-between">
                <h3 className="text-[14px] font-bold text-[#F3EADB]">Members</h3>
                <span className="text-[12px] font-bold text-[#8A7D67] bg-white/[0.05] px-2 py-0.5 rounded-full">{members.length}</span>
              </div>
              <div className="divide-y divide-[rgba(255,244,210,0.04)]">
                {members.map((m) => (
                  <div
                    key={m.userId}
                    onClick={() => handleMemberAction(m)}
                    className={`flex items-center gap-3 px-5 py-3.5 transition-colors ${isAdmin && m.userId !== user?.uid ? "hover:bg-[rgba(255,244,210,0.04)] cursor-pointer" : ""}`}
                  >
                    <div className="relative flex-shrink-0">
                      <img src={m.avatar} className="w-11 h-11 rounded-full object-cover" alt="" />
                      {m.online && <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#151310]" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-[15px] font-bold text-[#F3EADB] truncate">{m.name} {m.userId === user?.uid && "(You)"}</p>
                        {m.role === "owner" && (
                          <span className="text-[9px] font-black px-1.5 py-0.5 rounded text-amber-300 bg-amber-400/15 uppercase tracking-wider">Owner</span>
                        )}
                        {m.role === "admin" && (
                          <span className="text-[9px] font-black px-1.5 py-0.5 rounded text-sky-300 bg-sky-400/15 uppercase tracking-wider">Admin</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1 overflow-x-auto no-scrollbar">
                        {m.tags.map(t => (
                          <span key={t.id} className="flex-shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full border whitespace-nowrap"
                            style={{ background: t.color + "22", color: t.color, borderColor: t.color + "55" }}>
                            {t.name}
                          </span>
                        ))}
                        {m.tags.length === 0 && <span className="text-[12px] text-[#6E6353]">No tags</span>}
                      </div>
                    </div>
                    {isAdmin && m.userId !== user?.uid && (
                      <div className="text-[#8A7D67]">
                        <I.more s={18} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

          </div>
        ) : null}
      </div>

      {/* Action Sheet for Member Options */}
      <ActionSheet
        isOpen={!!actionMember}
        onClose={() => setActionMember(null)}
        title={actionMember ? `Manage ${actionMember.name}` : ""}
        items={buildActionItems()}
      />

      {/* Tag Manager Sheet */}
      <AnimatePresence>
        {tagManageMember && (
          <TagManagerSheet
            member={tagManageMember}
            groupInfo={info!}
            allTags={tags}
            onClose={() => setTagManageMember(null)}
            onChanged={loadData}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Tag Manager Sub-Sheet ──
function TagManagerSheet({
  member,
  groupInfo,
  allTags,
  onClose,
  onChanged,
}: {
  member: GroupMember;
  groupInfo: GroupInfo;
  allTags: GroupTag[];
  onClose: () => void;
  onChanged: () => void;
}) {
  const { user } = useAuth();
  const [newTagName, setNewTagName] = useState("");
  const [loading, setLoading] = useState(false);
  const memberTagIds = new Set(member.tags.map(t => t.id));

  const toggleTag = async (tag: GroupTag) => {
    if (!user) return;
    setLoading(true);
    try {
      if (memberTagIds.has(tag.id)) {
        await removeMemberTag(groupInfo.id, member.userId, tag.id);
      } else {
        await assignMemberTag(groupInfo.id, user.uid, user.name, member.userId, member.name, tag.id, tag.name);
      }
      await onChanged();
    } finally {
      setLoading(false);
    }
  };

  const createTag = async () => {
    if (!user || !newTagName.trim()) return;
    setLoading(true);
    try {
      const colors = ["#F87171", "#FBBF24", "#34D399", "#60A5FA", "#A78BFA", "#C084FC", "#F472B6"];
      const randomColor = colors[Math.floor(Math.random() * colors.length)];
      const tId = await createGroupTag(groupInfo.id, user.uid, user.name, newTagName.trim(), randomColor);
      await assignMemberTag(groupInfo.id, user.uid, user.name, member.userId, member.name, tId, newTagName.trim());
      setNewTagName("");
      await onChanged();
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 32 }}
        className="fixed inset-x-0 bottom-0 z-[70] mx-auto max-w-md bg-[#1A1814] rounded-t-[32px] overflow-hidden flex flex-col max-h-[85vh] border-t border-[rgba(216,173,90,0.15)]"
      >
        <div className="px-5 py-4 border-b border-white/[0.06] flex items-center justify-between">
          <div>
            <p className="text-[16px] font-bold text-[#F3EADB]">Manage Tags</p>
            <p className="text-[12px] text-[#8A7D67]">For {member.name}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/[0.06] flex items-center justify-center text-[#F3EADB]">
            <I.x s={16} />
          </button>
        </div>

        <div className="p-5 overflow-y-auto">
          {/* Create new tag */}
          <div className="flex items-center gap-2 mb-6">
            <input
              value={newTagName}
              onChange={(e) => setNewTagName(e.target.value)}
              placeholder="New tag name..."
              className="flex-1 h-10 px-4 rounded-xl bg-black/40 border border-white/[0.1] text-[#F3EADB] text-[13px] outline-none focus:border-[#D8AD5A]"
            />
            <button
              onClick={createTag}
              disabled={!newTagName.trim() || loading}
              className="h-10 px-4 rounded-xl font-bold text-[13px] text-black disabled:opacity-50"
              style={{ background: "linear-gradient(170deg,#FFF1CC,#E3B25D)" }}
            >
              Create
            </button>
          </div>

          {/* List existing tags */}
          <div className="space-y-2">
            <p className="text-[11px] font-bold text-[#6E6353] uppercase tracking-wider mb-2">Available Tags</p>
            {allTags.length === 0 ? (
              <p className="text-[13px] text-[#6E6353]">No tags created yet.</p>
            ) : (
              allTags.map((tag) => {
                const isAssigned = memberTagIds.has(tag.id);
                return (
                  <div key={tag.id} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/[0.04]">
                    <span className="text-[13px] font-bold px-2.5 py-1 rounded-full border"
                      style={{ background: tag.color + "22", color: tag.color, borderColor: tag.color + "55" }}>
                      {tag.name}
                    </span>
                    <button
                      onClick={() => toggleTag(tag)}
                      disabled={loading}
                      className={`w-20 h-8 rounded-lg text-[12px] font-bold transition-colors ${
                        isAssigned ? "bg-red-500/15 text-red-400 hover:bg-red-500/25" : "bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25"
                      }`}
                    >
                      {isAssigned ? "Remove" : "Assign"}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </motion.div>
    </>
  );
}
