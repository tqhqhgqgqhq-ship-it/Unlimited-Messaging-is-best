import JSZip from "jszip";
import fs from "fs";
import path from "path";

const ZIP_URL = "https://archive.org/download/modify-existing-messaging-app-4/strict-application-development-constraints%20%283%29.zip";

async function downloadAndExtract() {
  console.log("Downloading ZIP from archive.org...");
  const response = await fetch(ZIP_URL);
  if (!response.ok) {
    throw new Error(`Failed to download: ${response.status} ${response.statusText}`);
  }
  
  const arrayBuffer = await response.arrayBuffer();
  console.log(`Downloaded ${arrayBuffer.byteLength} bytes`);
  
  const zip = await JSZip.loadAsync(arrayBuffer);
  
  // Extract all files
  for (const [filename, file] of Object.entries(zip.files)) {
    if (file.dir) continue;
    
    // Skip files in _orig_extract (they're duplicates)
    if (filename.startsWith("_orig_extract/")) {
      // Extract to root without _orig_extract prefix
      const targetPath = filename.replace("_orig_extract/", "");
      const content = await file.async("string");
      
      // Create directory if needed
      const dir = path.dirname(targetPath);
      if (dir && dir !== ".") {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(targetPath, content);
      console.log(`Extracted: ${targetPath}`);
    } else if (!filename.startsWith("_")) {
      // Extract root-level files
      const content = await file.async("string");
      
      const dir = path.dirname(filename);
      if (dir && dir !== ".") {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(filename, content);
      console.log(`Extracted: ${filename}`);
    }
  }
  
  console.log("Extraction complete!");
}

downloadAndExtract().catch(console.error);
