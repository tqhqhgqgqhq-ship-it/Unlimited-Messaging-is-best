# Animated Emoji Collection

Place your 1000+ animated emoji GIF files in this folder.

## File Naming Convention

Each emoji animation file should be named after the emoji's short name:

```
grinning.gif    → 😀
smiley.gif      → 😃
smile.gif       → 😄
joy.gif         → 😂
heart_eyes.gif  → 😍
```

## How to Add Your Emoji Zip

1. Download your emoji zip from: https://gofile.io/d/38hLzT
2. Extract all GIF files into this `public/emoji/` folder
3. Ensure file names match the emoji names in `src/lib/emoji-animations.ts`
4. The app will automatically detect and render animated emoji!

## Supported Formats

- **GIF** (recommended) - Works everywhere, no dependencies
- **Lottie JSON** - Higher quality, smaller files (requires @lottiefiles/web-components)

## Current Mapped Emoji

Check `src/lib/emoji-animations.ts` for the full list of 150+ pre-mapped emoji.
You can add more by extending the `EMOJI_ANIMATIONS` array.

## Example Structure

```
public/
  emoji/
    grinning.gif
    smiley.gif
    smile.gif
    joy.gif
    heart_eyes.gif
    ... (1000+ more)
```

## Usage in Chat

When a user sends a message containing emoji:
- If the emoji has an animation → renders as animated GIF
- If no animation exists → renders as static emoji character
- Messages with ONLY emoji render larger (48px)
- Messages with text + emoji render inline (32px)
